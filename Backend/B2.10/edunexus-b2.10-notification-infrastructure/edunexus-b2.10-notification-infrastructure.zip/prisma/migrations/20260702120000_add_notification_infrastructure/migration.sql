-- B2.10 — Enterprise Notification & Communication Infrastructure
-- Standalone migration. Apply during B2.21 consolidation after the
-- corresponding models are appended to prisma/schema.prisma.

-- CreateEnum
CREATE TYPE "NotificationChannel" AS ENUM ('EMAIL', 'SMS', 'PUSH', 'IN_APP', 'WEBSOCKET');

-- CreateEnum
CREATE TYPE "NotificationCategory" AS ENUM ('ACADEMIC', 'FINANCE', 'ATTENDANCE', 'DISCIPLINE', 'TRANSPORT', 'HOSTEL', 'LIBRARY', 'SECURITY', 'EMERGENCY', 'SYSTEM');

-- CreateEnum
CREATE TYPE "DeliveryStatus" AS ENUM ('PENDING', 'QUEUED', 'SENT', 'DELIVERED', 'FAILED', 'CANCELLED', 'READ', 'OPENED', 'CLICKED');

-- CreateTable
CREATE TABLE "notifications" (
    "id" TEXT NOT NULL,
    "tenant_id" TEXT NOT NULL,
    "school_group_id" TEXT,
    "school_id" TEXT,
    "campus_id" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "created_by" TEXT,
    "updated_by" TEXT,
    "deleted_by" TEXT,
    "recipient_user_id" TEXT NOT NULL,
    "category" "NotificationCategory" NOT NULL,
    "channels" "NotificationChannel"[],
    "title" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "data" JSONB,
    "template_code" TEXT,
    "locale" TEXT NOT NULL DEFAULT 'en',
    "status" "DeliveryStatus" NOT NULL DEFAULT 'PENDING',
    "failure_reason" TEXT,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "max_attempts" INTEGER NOT NULL DEFAULT 5,
    "scheduled_for" TIMESTAMP(3),
    "sent_at" TIMESTAMP(3),
    "delivered_at" TIMESTAMP(3),
    "read_at" TIMESTAMP(3),
    "opened_at" TIMESTAMP(3),
    "clicked_at" TIMESTAMP(3),
    "cancelled_at" TIMESTAMP(3),
    "batch_id" TEXT,
    "correlation_id" TEXT,
    "created_by_actor" TEXT,

    CONSTRAINT "notifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notification_templates" (
    "id" TEXT NOT NULL,
    "tenant_id" TEXT NOT NULL,
    "school_group_id" TEXT,
    "school_id" TEXT,
    "campus_id" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "created_by" TEXT,
    "updated_by" TEXT,
    "deleted_by" TEXT,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" "NotificationCategory" NOT NULL,
    "channel" "NotificationChannel" NOT NULL,
    "locale" TEXT NOT NULL DEFAULT 'en',
    "subject" TEXT,
    "body_html" TEXT,
    "body_text" TEXT,
    "variables" TEXT[],
    "is_active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "notification_templates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notification_preferences" (
    "id" TEXT NOT NULL,
    "tenant_id" TEXT NOT NULL,
    "school_group_id" TEXT,
    "school_id" TEXT,
    "campus_id" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "created_by" TEXT,
    "updated_by" TEXT,
    "deleted_by" TEXT,
    "user_id" TEXT NOT NULL,
    "email_enabled" BOOLEAN NOT NULL DEFAULT true,
    "sms_enabled" BOOLEAN NOT NULL DEFAULT true,
    "push_enabled" BOOLEAN NOT NULL DEFAULT true,
    "in_app_enabled" BOOLEAN NOT NULL DEFAULT true,
    "quiet_hours_start" TEXT,
    "quiet_hours_end" TEXT,
    "quiet_hours_timezone" TEXT NOT NULL DEFAULT 'Africa/Nairobi',
    "language" TEXT NOT NULL DEFAULT 'en',
    "category_overrides" JSONB,
    "muted_categories" "NotificationCategory"[],

    CONSTRAINT "notification_preferences_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "notifications_tenant_id_idx" ON "notifications"("tenant_id");
CREATE INDEX "notifications_deleted_at_idx" ON "notifications"("deleted_at");
CREATE INDEX "notifications_tenant_id_recipient_user_id_idx" ON "notifications"("tenant_id", "recipient_user_id");
CREATE INDEX "notifications_tenant_id_status_idx" ON "notifications"("tenant_id", "status");
CREATE INDEX "notifications_tenant_id_batch_id_idx" ON "notifications"("tenant_id", "batch_id");
CREATE INDEX "notifications_tenant_id_category_idx" ON "notifications"("tenant_id", "category");

-- CreateIndex
CREATE INDEX "notification_templates_tenant_id_idx" ON "notification_templates"("tenant_id");
CREATE INDEX "notification_templates_deleted_at_idx" ON "notification_templates"("deleted_at");
CREATE UNIQUE INDEX "notification_templates_tenant_id_code_channel_locale_key" ON "notification_templates"("tenant_id", "code", "channel", "locale");

-- CreateIndex
CREATE INDEX "notification_preferences_tenant_id_idx" ON "notification_preferences"("tenant_id");
CREATE INDEX "notification_preferences_deleted_at_idx" ON "notification_preferences"("deleted_at");
CREATE UNIQUE INDEX "notification_preferences_tenant_id_user_id_key" ON "notification_preferences"("tenant_id", "user_id");
