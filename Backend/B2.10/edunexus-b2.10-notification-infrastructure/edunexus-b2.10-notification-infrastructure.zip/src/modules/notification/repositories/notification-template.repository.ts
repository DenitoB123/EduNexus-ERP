import { Injectable } from '@nestjs/common';
import { SoftDeleteRepository } from '../../../common/repositories/soft-delete.repository';
import { PrismaFullModelDelegate } from '../../../common/repositories/interfaces/prisma-full-delegate.interface';
import { NotificationTemplate } from '../interfaces/notification-entity.interface';

@Injectable()
export class NotificationTemplateRepository extends SoftDeleteRepository<NotificationTemplate> {
  protected readonly modelName = 'NotificationTemplate';
  protected readonly allowedFilterFields = ['code', 'category', 'channel', 'locale', 'isActive'];
  protected readonly allowedSearchFields = ['name', 'code'];

  constructor(delegate: PrismaFullModelDelegate<NotificationTemplate>) {
    super(delegate);
  }

  async findByCodeChannelLocale(
    code: string,
    channel: string,
    locale: string,
    tenantId: string,
  ): Promise<NotificationTemplate | null> {
    return this.findOne(
      {
        filters: [
          { field: 'code', operator: 'eq', value: code },
          { field: 'channel', operator: 'eq', value: channel },
          { field: 'locale', operator: 'eq', value: locale },
        ],
      },
      tenantId,
    );
  }
}
