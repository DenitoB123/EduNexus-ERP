import { Injectable } from '@nestjs/common';
import { SoftDeleteRepository } from '../../../common/repositories/soft-delete.repository';
import { PrismaFullModelDelegate } from '../../../common/repositories/interfaces/prisma-full-delegate.interface';
import { NotificationPreference } from '../interfaces/notification-entity.interface';

@Injectable()
export class NotificationPreferenceRepository extends SoftDeleteRepository<NotificationPreference> {
  protected readonly modelName = 'NotificationPreference';
  protected readonly allowedFilterFields = ['userId'];
  protected readonly allowedSearchFields = [];

  constructor(delegate: PrismaFullModelDelegate<NotificationPreference>) {
    super(delegate);
  }

  async findByUserId(userId: string, tenantId: string): Promise<NotificationPreference | null> {
    return this.findOne({ filters: [{ field: 'userId', operator: 'eq', value: userId }] }, tenantId);
  }
}
