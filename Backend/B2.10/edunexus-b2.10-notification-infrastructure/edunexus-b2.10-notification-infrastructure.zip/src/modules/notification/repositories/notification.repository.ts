import { Injectable } from '@nestjs/common';
import { SoftDeleteRepository } from '../../../common/repositories/soft-delete.repository';
import { PrismaFullModelDelegate } from '../../../common/repositories/interfaces/prisma-full-delegate.interface';
import { Notification } from '../interfaces/notification-entity.interface';

/**
 * Follows the B2.2 repository hierarchy documented in
 * common/repositories/soft-delete.repository.ts: business modules
 * extend SoftDeleteRepository directly for any entity that carries
 * the mandatory base-field convention. Notification does (see
 * prisma/notification-schema-addition.prisma).
 */
@Injectable()
export class NotificationRepository extends SoftDeleteRepository<Notification> {
  protected readonly modelName = 'Notification';
  protected readonly allowedFilterFields = ['recipientUserId', 'category', 'status', 'batchId', 'correlationId'];
  protected readonly allowedSearchFields = ['title', 'body'];

  constructor(delegate: PrismaFullModelDelegate<Notification>) {
    super(delegate);
  }
}
