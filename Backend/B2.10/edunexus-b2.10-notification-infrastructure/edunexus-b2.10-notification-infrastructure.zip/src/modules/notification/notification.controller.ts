import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { RolesGuard } from '../../common/guards/roles.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { RequirePermissions } from '../../common/decorators/require-access.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { CurrentTenant } from '../../common/decorators/current-tenant.decorator';
import { NotificationService } from './notification.service';
import { PreferenceService } from './preferences/preference.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { BroadcastNotificationDto } from './dto/broadcast-notification.dto';
import { UpdatePreferenceDto } from './dto/update-preference.dto';
import { NotificationQueryDto } from './dto/notification-query.dto';

/**
 * JwtAuthGuard is already registered globally via APP_GUARD in
 * app.module.ts, so it is not re-declared here. RolesGuard and
 * PermissionsGuard are opt-in per controller (not global) and both
 * currently log-and-allow when no Auth module has populated
 * request.authContext — see common/guards/*.guard.ts — so these
 * routes are inert-safe today and become enforced automatically
 * once that module lands.
 */
@Controller('notifications')
@UseGuards(RolesGuard, PermissionsGuard)
export class NotificationController {
  constructor(
    private readonly notificationService: NotificationService,
    private readonly preferenceService: PreferenceService,
  ) {}

  @Post()
  @RequirePermissions('notification:create')
  create(
    @Body() dto: CreateNotificationDto,
    @CurrentTenant() tenantId: string,
    @CurrentUser() actorId?: string,
  ) {
    return this.notificationService.create(dto, tenantId, actorId);
  }

  @Post('broadcast')
  @RequirePermissions('notification:broadcast')
  broadcast(
    @Body() dto: BroadcastNotificationDto,
    @CurrentTenant() tenantId: string,
    @CurrentUser() actorId?: string,
  ) {
    return this.notificationService.broadcast(dto, tenantId, actorId);
  }

  @Get()
  @RequirePermissions('notification:read')
  history(@Query() query: NotificationQueryDto, @CurrentTenant() tenantId: string) {
    return this.notificationService.history(query, tenantId);
  }

  @Post(':id/retry')
  @RequirePermissions('notification:manage')
  retry(@Param('id') id: string, @CurrentTenant() tenantId: string) {
    return this.notificationService.retry(id, tenantId);
  }

  @Post(':id/cancel')
  @RequirePermissions('notification:manage')
  cancel(
    @Param('id') id: string,
    @CurrentTenant() tenantId: string,
    @Body('reason') reason?: string,
  ) {
    return this.notificationService.cancel(id, tenantId, reason);
  }

  @Patch(':id/read')
  markRead(@Param('id') id: string, @CurrentTenant() tenantId: string) {
    return this.notificationService.markRead(id, tenantId);
  }

  @Patch(':id/opened')
  markOpened(@Param('id') id: string, @CurrentTenant() tenantId: string) {
    return this.notificationService.markOpened(id, tenantId);
  }

  @Patch(':id/clicked')
  markClicked(@Param('id') id: string, @CurrentTenant() tenantId: string) {
    return this.notificationService.markClicked(id, tenantId);
  }

  @Patch(':id/delivered')
  @RequirePermissions('notification:manage')
  markDelivered(@Param('id') id: string, @CurrentTenant() tenantId: string) {
    return this.notificationService.markDelivered(id, tenantId);
  }

  @Get('preferences/me')
  getMyPreferences(@CurrentUser() userId: string, @CurrentTenant() tenantId: string) {
    return this.preferenceService.getOrDefault(userId, tenantId);
  }

  @Patch('preferences/me')
  updateMyPreferences(
    @Body() dto: UpdatePreferenceDto,
    @CurrentUser() userId: string,
    @CurrentTenant() tenantId: string,
  ) {
    return this.preferenceService.update(userId, dto, tenantId, userId);
  }
}
