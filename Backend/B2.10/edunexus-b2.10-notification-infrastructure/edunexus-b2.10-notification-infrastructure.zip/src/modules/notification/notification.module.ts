import { Module } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { NotificationController } from './notification.controller';
import { NotificationService } from './notification.service';

import { NotificationRepository } from './repositories/notification.repository';
import { NotificationTemplateRepository } from './repositories/notification-template.repository';
import { NotificationPreferenceRepository } from './repositories/notification-preference.repository';

import { ChannelFactory } from './channels/channel.factory';
import { ChannelService } from './channels/channel.service';
import { NullRecipientDirectory } from './channels/recipient-directory.default';
import {
  CustomGroupRecipientResolver,
  UnresolvedOrgRecipientResolver,
  UserRecipientResolver,
} from './channels/recipient-resolvers';

import { TemplateRenderer } from './templates/template.renderer';
import { TemplateService } from './templates/template.service';

import { PreferenceService } from './preferences/preference.service';

import { EmailChannelProvider } from './providers/email.provider';
import { SmsChannelProvider } from './providers/sms.provider';
import { PushChannelProvider } from './providers/push.provider';
import { InAppChannelProvider } from './providers/inapp.provider';
import { WebSocketChannelProvider } from './providers/websocket.provider';
import { NotificationGateway } from './gateway/notification.gateway';

import { SendNotificationJobHandler } from './jobs/send-notification.job-handler';

import {
  NOTIFICATION_CHANNEL_PROVIDERS,
  RECIPIENT_RESOLVERS,
  RecipientTargetType,
} from './constants/notification.constants';
import { RECIPIENT_DIRECTORY } from './interfaces/recipient-directory.interface';

/**
 * Standalone, mergeable module per the B2.10 parallel-milestone
 * contract. No `imports` array is needed for EmailModule/SmsModule/
 * PushModule/JobModule/PrismaModule/DatabaseModule/EventModule —
 * they are all declared @Global() in the foundation (B1.1-B2.2) and
 * are therefore already available for injection anywhere in the
 * app once AppModule has bootstrapped them.
 *
 * PrismaService itself IS imported explicitly only to build the
 * three repository delegates below (`prisma.notification`, etc.),
 * matching the injection-token pattern documented in
 * common/repositories/repository-hierarchy.spec.ts.
 */
@Module({
  controllers: [NotificationController],
  providers: [
    NotificationService,
    ChannelService,
    ChannelFactory,
    TemplateService,
    TemplateRenderer,
    PreferenceService,
    NotificationGateway,
    SendNotificationJobHandler,

    {
      provide: NotificationRepository,
      useFactory: (prisma: PrismaService) => new NotificationRepository((prisma as any).notification),
      inject: [PrismaService],
    },
    {
      provide: NotificationTemplateRepository,
      useFactory: (prisma: PrismaService) => new NotificationTemplateRepository((prisma as any).notificationTemplate),
      inject: [PrismaService],
    },
    {
      provide: NotificationPreferenceRepository,
      useFactory: (prisma: PrismaService) => new NotificationPreferenceRepository((prisma as any).notificationPreference),
      inject: [PrismaService],
    },

    // Channel provider registry (extensible: add a class + one line here).
    EmailChannelProvider,
    SmsChannelProvider,
    PushChannelProvider,
    InAppChannelProvider,
    WebSocketChannelProvider,
    {
      provide: NOTIFICATION_CHANNEL_PROVIDERS,
      useFactory: (
        email: EmailChannelProvider,
        sms: SmsChannelProvider,
        push: PushChannelProvider,
        inApp: InAppChannelProvider,
        ws: WebSocketChannelProvider,
      ) => [email, sms, push, inApp, ws],
      inject: [EmailChannelProvider, SmsChannelProvider, PushChannelProvider, InAppChannelProvider, WebSocketChannelProvider],
    },

    // Recipient resolver registry — CLASS/DEPARTMENT/CAMPUS/INSTITUTION
    // are bound to the inert UnresolvedOrgRecipientResolver until a
    // future org-structure module rebinds them (see recipient-resolvers.ts).
    UserRecipientResolver,
    CustomGroupRecipientResolver,
    {
      provide: RECIPIENT_RESOLVERS,
      useFactory: (user: UserRecipientResolver, group: CustomGroupRecipientResolver) => [
        user,
        group,
        new UnresolvedOrgRecipientResolver(RecipientTargetType.CLASS),
        new UnresolvedOrgRecipientResolver(RecipientTargetType.DEPARTMENT),
        new UnresolvedOrgRecipientResolver(RecipientTargetType.CAMPUS),
        new UnresolvedOrgRecipientResolver(RecipientTargetType.INSTITUTION),
      ],
      inject: [UserRecipientResolver, CustomGroupRecipientResolver],
    },

    // Contact-info directory — rebind this provider to a real
    // implementation once a Users module exists (see
    // interfaces/recipient-directory.interface.ts).
    { provide: RECIPIENT_DIRECTORY, useClass: NullRecipientDirectory },
  ],
  exports: [NotificationService, PreferenceService, TemplateService, NotificationGateway],
})
export class NotificationModule {}
