import { Injectable, OnModuleInit } from '@nestjs/common';
import { JobHandlerBase } from '../../../infrastructure/jobs/job-handler.base';
import { JobRegistry } from '../../../infrastructure/jobs/job-registry.service';
import { JobPayload } from '../../../infrastructure/interfaces/job.interface';
import { AppLoggerService } from '../../../common/logger/app-logger.service';
import { EventBus } from '../../../infrastructure/events/event-bus.service';
import { NotificationRepository } from '../repositories/notification.repository';
import { ChannelService } from '../channels/channel.service';
import { DeliveryStatus, NOTIFICATION_JOB_NAME } from '../constants/notification.constants';
import {
  NotificationFailedEvent,
  NotificationSentEvent,
} from '../events/notification.events';

export interface NotificationJobData {
  notificationId: string;
  tenantId: string;
}

/**
 * Registered with the existing B2.2 JobRegistry/ConsumerService
 * pipeline (infrastructure/jobs, infrastructure/rabbitmq) — this
 * class does NOT open its own queue connection or implement retry
 * backoff; MessageRetryStrategy on the RabbitMQ consumer already
 * does that. Throwing from process() signals "please retry" to that
 * existing mechanism.
 */
@Injectable()
export class SendNotificationJobHandler extends JobHandlerBase<NotificationJobData> implements OnModuleInit {
  readonly name = NOTIFICATION_JOB_NAME;

  constructor(
    private readonly jobRegistry: JobRegistry,
    private readonly notificationRepository: NotificationRepository,
    private readonly channelService: ChannelService,
    private readonly eventBus: EventBus,
    private readonly logger: AppLoggerService,
  ) {
    super();
    this.logger.setContext(SendNotificationJobHandler.name);
  }

  onModuleInit(): void {
    this.jobRegistry.register(this);
  }

  async process(payload: JobPayload<NotificationJobData>): Promise<void> {
    const { notificationId, tenantId } = payload.data;
    const notification = await this.notificationRepository.findById(notificationId, tenantId);

    if (!notification) {
      this.logger.warn(`Notification ${notificationId} no longer exists; skipping dispatch job.`);
      return;
    }

    if (notification.status === DeliveryStatus.CANCELLED) {
      this.logger.log(`Notification ${notificationId} was cancelled before dispatch; skipping.`);
      return;
    }

    const outcomes = await this.channelService.dispatchAll(notification, tenantId);
    const failures = outcomes.filter((o) => !o.success && !o.skipped);
    const anySent = outcomes.some((o) => o.success);
    const attempts = payload.attempts + 1;

    if (failures.length === 0) {
      await this.notificationRepository.update(
        notification.id,
        { status: DeliveryStatus.SENT, sentAt: new Date(), attempts },
        tenantId,
      );
      for (const outcome of outcomes.filter((o) => o.success)) {
        await this.eventBus.emit(
          new NotificationSentEvent(notification.id, outcome.channel, outcome.providerMessageId),
        );
      }
      // DELIVERED is a stronger guarantee than "accepted by provider"
      // (bounce/webhook confirmation) — providers that support delivery
      // webhooks call NotificationService.markDelivered(); until then
      // SENT is the terminal success state recorded here.
      return;
    }

    if (anySent) {
      // Partial success (e.g. EMAIL sent, SMS provider down): record
      // SENT for the notification as a whole but surface the failure
      // via the event so operators can see per-channel detail.
      await this.notificationRepository.update(
        notification.id,
        { status: DeliveryStatus.SENT, sentAt: new Date(), attempts, failureReason: this.summarizeFailures(failures) },
        tenantId,
      );
      for (const failure of failures) {
        await this.eventBus.emit(
          new NotificationFailedEvent(notification.id, failure.channel, failure.reason ?? 'unknown error', attempts),
        );
      }
      return;
    }

    const failureReason = this.summarizeFailures(failures);

    if (attempts >= payload.maxAttempts) {
      await this.notificationRepository.update(
        notification.id,
        { status: DeliveryStatus.FAILED, failureReason, attempts },
        tenantId,
      );
      for (const failure of failures) {
        await this.eventBus.emit(
          new NotificationFailedEvent(notification.id, failure.channel, failure.reason ?? 'unknown error', attempts),
        );
      }
      return;
    }

    await this.notificationRepository.update(notification.id, { attempts, failureReason }, tenantId);
    // Re-throw so the RabbitMQ consumer's MessageRetryStrategy requeues this job.
    throw new Error(
      `Notification ${notification.id} dispatch failed on all channels (attempt ${attempts}): ${failureReason}`,
    );
  }

  private summarizeFailures(failures: { channel: string; reason?: string }[]): string {
    return failures.map((f) => `${f.channel}: ${f.reason ?? 'unknown error'}`).join('; ');
  }
}
