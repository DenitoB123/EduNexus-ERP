import { Injectable, Logger } from '@nestjs/common';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { AppConfigService } from '../../../config/app-config.service';

/**
 * Real-time push channel for WEBSOCKET notifications.
 *
 * New capability introduced by B2.10 — the foundation (B1.1-B2.2)
 * has no WebSocket infrastructure yet, so this gateway is additive.
 * It requires @nestjs/websockets, @nestjs/platform-socket.io and
 * socket.io as new package.json dependencies (see
 * IMPLEMENTATION_SUMMARY_B2_10.md, "New dependencies").
 *
 * Auth model mirrors JwtAuthGuard (common/guards/jwt-auth.guard.ts):
 * verifies the bearer JWT on connection, but — consistent with that
 * guard's documented Phase 1 scope — does not resolve full
 * roles/permissions since no Auth/Users module exists yet. Once one
 * exists, socket.data.userId here is the integration point.
 */
@Injectable()
@WebSocketGateway({
  namespace: '/notifications',
  cors: { origin: '*', credentials: true },
})
export class NotificationGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(NotificationGateway.name);
  private readonly userSockets = new Map<string, Set<string>>();

  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: AppConfigService,
  ) {}

  handleConnection(client: Socket): void {
    const token = this.extractToken(client);
    if (!token) {
      client.disconnect(true);
      return;
    }

    try {
      const payload = this.jwtService.verify<{ sub?: string; userId?: string }>(token, {
        secret: this.configService.jwt.secret,
      });
      const userId = payload.userId ?? payload.sub;
      if (!userId) {
        client.disconnect(true);
        return;
      }

      client.data.userId = userId;
      this.registerSocket(userId, client.id);
      client.join(this.roomFor(userId));
    } catch {
      client.disconnect(true);
    }
  }

  handleDisconnect(client: Socket): void {
    const userId = client.data?.userId as string | undefined;
    if (userId) this.unregisterSocket(userId, client.id);
  }

  @SubscribeMessage('ping')
  handlePing(): { pong: boolean } {
    return { pong: true };
  }

  /** Called by WebSocketChannelProvider to push a rendered notification live. */
  emitToUser(userId: string, event: string, payload: Record<string, unknown>): void {
    this.server.to(this.roomFor(userId)).emit(event, payload);
  }

  isUserOnline(userId: string): boolean {
    return (this.userSockets.get(userId)?.size ?? 0) > 0;
  }

  private roomFor(userId: string): string {
    return `user:${userId}`;
  }

  private registerSocket(userId: string, socketId: string): void {
    if (!this.userSockets.has(userId)) this.userSockets.set(userId, new Set());
    this.userSockets.get(userId)!.add(socketId);
  }

  private unregisterSocket(userId: string, socketId: string): void {
    const sockets = this.userSockets.get(userId);
    if (!sockets) return;
    sockets.delete(socketId);
    if (sockets.size === 0) this.userSockets.delete(userId);
  }

  private extractToken(client: Socket): string | undefined {
    const authHeader = client.handshake.auth?.token as string | undefined;
    const headerToken = client.handshake.headers.authorization?.split(' ')[1];
    return authHeader ?? headerToken;
  }
}
