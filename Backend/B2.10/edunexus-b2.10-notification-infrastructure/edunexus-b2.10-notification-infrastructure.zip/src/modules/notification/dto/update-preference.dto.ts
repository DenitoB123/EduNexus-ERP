import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsObject,
  IsOptional,
  IsString,
  Matches,
} from 'class-validator';
import { NotificationCategory, NotificationChannel, SUPPORTED_LOCALES } from '../constants/notification.constants';

const HH_MM = /^([01]\d|2[0-3]):[0-5]\d$/;

export class UpdatePreferenceDto {
  @IsOptional()
  @IsBoolean()
  emailEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  smsEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  pushEnabled?: boolean;

  @IsOptional()
  @IsBoolean()
  inAppEnabled?: boolean;

  @IsOptional()
  @Matches(HH_MM, { message: 'quietHoursStart must be HH:MM (24h)' })
  quietHoursStart?: string;

  @IsOptional()
  @Matches(HH_MM, { message: 'quietHoursEnd must be HH:MM (24h)' })
  quietHoursEnd?: string;

  @IsOptional()
  @IsString()
  quietHoursTimezone?: string;

  @IsOptional()
  @IsEnum(SUPPORTED_LOCALES)
  language?: string;

  @IsOptional()
  @IsObject()
  categoryOverrides?: Record<NotificationCategory, NotificationChannel[]>;

  @IsOptional()
  @IsArray()
  @IsEnum(NotificationCategory, { each: true })
  mutedCategories?: NotificationCategory[];
}
