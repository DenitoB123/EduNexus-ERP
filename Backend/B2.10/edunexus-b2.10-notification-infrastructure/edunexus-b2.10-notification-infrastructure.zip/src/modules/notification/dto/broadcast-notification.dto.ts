import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsObject,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { NotificationCategory, NotificationChannel, RecipientTargetType } from '../constants/notification.constants';

export class BroadcastTargetDto {
  @IsEnum(RecipientTargetType)
  targetType!: RecipientTargetType;

  /** Group/class/department/campus/institution id, or ignored for CUSTOM_GROUP (see userIds). */
  @IsOptional()
  @IsUUID()
  targetId?: string;

  /** Only used when targetType === CUSTOM_GROUP. */
  @IsOptional()
  @IsArray()
  @IsUUID('4', { each: true })
  userIds?: string[];
}

export class BroadcastNotificationDto {
  @ValidateNested()
  @Type(() => BroadcastTargetDto)
  target!: BroadcastTargetDto;

  @IsEnum(NotificationCategory)
  category!: NotificationCategory;

  @IsArray()
  @IsEnum(NotificationChannel, { each: true })
  channels!: NotificationChannel[];

  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  title!: string;

  @IsString()
  @IsNotEmpty()
  body!: string;

  @IsOptional()
  @IsObject()
  data?: Record<string, unknown>;

  @IsOptional()
  @IsString()
  templateCode?: string;

  @IsOptional()
  @IsString()
  locale?: string;
}
