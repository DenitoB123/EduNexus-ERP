/**
 * Contact-info lookup (email/phone/device tokens) for a userId.
 *
 * No Users/Auth module exists yet in the foundation this milestone
 * builds on (see common/guards/jwt-auth.guard.ts and
 * common/decorators/current-user.decorator.ts — both document the
 * same gap). Rather than block on that module or fabricate one here
 * (out of scope for B2.10), this is an inert extension point: a
 * future Users module provides a real implementation and rebinds
 * the RECIPIENT_DIRECTORY token in notification.module.ts. Until
 * then NullRecipientDirectory is used, and callers must supply
 * contact info explicitly via CreateNotificationDto.data.contactOverride
 * for EMAIL/SMS/PUSH to succeed.
 */
export interface RecipientContactInfo {
  email?: string;
  phone?: string;
  deviceTokens?: string[];
}

export interface IRecipientDirectory {
  getContactInfo(userId: string, tenantId: string): Promise<RecipientContactInfo | null>;
}

export const RECIPIENT_DIRECTORY = 'RECIPIENT_DIRECTORY';
