import { NotificationChannel } from '../constants/notification.constants';

/**
 * Contract every channel adapter (providers/*.provider.ts) implements.
 * The channel layer (channels/channel.factory.ts) resolves one of
 * these per NotificationChannel value — new channels are added by
 * implementing this interface and registering in the factory, never
 * by modifying NotificationService.
 */
export interface INotificationChannelProvider {
  readonly channel: NotificationChannel;
  send(message: RenderedNotificationMessage): Promise<ChannelSendResult>;
}

export interface RenderedNotificationMessage {
  recipientUserId: string;
  to: ChannelDestination;
  subject: string;
  bodyHtml?: string;
  bodyText: string;
  data?: Record<string, unknown>;
  notificationId: string;
  correlationId?: string;
}

/**
 * Resolved per-channel destination. Populated by the preference/user
 * lookup step before dispatch — e.g. email address for EMAIL, phone
 * number for SMS, device tokens for PUSH, userId alone for IN_APP/WEBSOCKET.
 */
export interface ChannelDestination {
  email?: string;
  phone?: string;
  deviceTokens?: string[];
  userId: string;
}

export interface ChannelSendResult {
  success: boolean;
  providerMessageId?: string;
  error?: string;
}

/**
 * Recipient targeting is intentionally kept out of this module's
 * business logic. B2.10 ships resolvers for USER and CUSTOM_GROUP
 * only; CLASS/DEPARTMENT/CAMPUS/INSTITUTION resolvers are extension
 * points that later SIS/Org modules register against the same
 * RECIPIENT_RESOLVERS multi-provider token — this module never
 * assumes those business models exist.
 */
export interface IRecipientResolver {
  readonly targetType: string;
  resolve(targetId: string, tenantId: string): Promise<string[]>;
}
