import { BaseModel } from '../../../database/interfaces/base-model.interface';
import { DeliveryStatus, NotificationCategory, NotificationChannel } from '../constants/notification.constants';

/**
 * Persisted notification record. Extends the mandatory B1.2/B2.2
 * BaseModel convention (tenantId, version, audit fields, soft delete)
 * so NotificationRepository can extend SoftDeleteRepository directly.
 */
export interface Notification extends BaseModel {
  recipientUserId: string;
  category: NotificationCategory;
  channels: NotificationChannel[];
  title: string;
  body: string;
  data: Record<string, unknown> | null;
  templateCode: string | null;
  locale: string;
  status: DeliveryStatus;
  failureReason: string | null;
  attempts: number;
  maxAttempts: number;
  scheduledFor: Date | null;
  sentAt: Date | null;
  deliveredAt: Date | null;
  readAt: Date | null;
  openedAt: Date | null;
  clickedAt: Date | null;
  cancelledAt: Date | null;
  batchId: string | null;
  correlationId: string | null;
  createdByActor: string | null;
}

export interface NotificationPreference extends BaseModel {
  userId: string;
  emailEnabled: boolean;
  smsEnabled: boolean;
  pushEnabled: boolean;
  inAppEnabled: boolean;
  quietHoursStart: string | null;
  quietHoursEnd: string | null;
  quietHoursTimezone: string;
  language: string;
  categoryOverrides: Record<string, NotificationChannel[]> | null;
  mutedCategories: NotificationCategory[];
}

export interface NotificationTemplate extends BaseModel {
  code: string;
  name: string;
  category: NotificationCategory;
  channel: NotificationChannel;
  locale: string;
  subject: string | null;
  bodyHtml: string | null;
  bodyText: string | null;
  variables: string[];
  isActive: boolean;
}
