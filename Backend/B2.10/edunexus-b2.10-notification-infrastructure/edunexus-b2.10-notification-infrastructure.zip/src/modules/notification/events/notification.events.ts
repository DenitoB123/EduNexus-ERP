import { DomainEvent } from '../../../infrastructure/events/event.base';
import { NotificationEventName, DeliveryStatus } from '../constants/notification.constants';

/**
 * All events extend the existing infrastructure DomainEvent base
 * (infrastructure/events/event.base.ts) so they flow through the
 * same EventBus/EventDispatcher/EventRegistry pipeline every other
 * module uses — no parallel event system introduced here.
 */
export class NotificationCreatedEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly recipientUserId: string,
    public readonly category: string,
  ) {
    super(NotificationEventName.CREATED);
  }
}

export class NotificationQueuedEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly channel: string,
  ) {
    super(NotificationEventName.QUEUED);
  }
}

export class NotificationSentEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly channel: string,
    public readonly providerMessageId?: string,
  ) {
    super(NotificationEventName.SENT);
  }
}

export class NotificationDeliveredEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly channel: string,
  ) {
    super(NotificationEventName.DELIVERED);
  }
}

export class NotificationFailedEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly channel: string,
    public readonly reason: string,
    public readonly attempts: number,
  ) {
    super(NotificationEventName.FAILED);
  }
}

export class NotificationCancelledEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly reason?: string,
  ) {
    super(NotificationEventName.CANCELLED);
  }
}

export class NotificationEngagementEvent extends DomainEvent {
  constructor(
    public readonly notificationId: string,
    public readonly status: typeof DeliveryStatus.READ | typeof DeliveryStatus.OPENED | typeof DeliveryStatus.CLICKED,
    eventName: string,
  ) {
    super(eventName);
  }
}

export class NotificationPreferenceUpdatedEvent extends DomainEvent {
  constructor(
    public readonly userId: string,
    public readonly changedFields: string[],
  ) {
    super(NotificationEventName.PREFERENCE_UPDATED);
  }
}
