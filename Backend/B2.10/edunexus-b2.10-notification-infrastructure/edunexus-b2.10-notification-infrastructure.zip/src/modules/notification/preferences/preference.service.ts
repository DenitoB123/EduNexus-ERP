import { Injectable } from '@nestjs/common';
import { EventBus } from '../../../infrastructure/events/event-bus.service';
import { NotificationPreferenceRepository } from '../repositories/notification-preference.repository';
import { NotificationPreference } from '../interfaces/notification-entity.interface';
import { NotificationCategory, NotificationChannel, DEFAULT_NOTIFICATION_LOCALE } from '../constants/notification.constants';
import { NotificationPreferenceUpdatedEvent } from '../events/notification.events';
import { UpdatePreferenceDto } from '../dto/update-preference.dto';

const DEFAULT_PREFERENCE: Omit<NotificationPreference, keyof import('../../../database/interfaces/base-model.interface').BaseModel> = {
  userId: '',
  emailEnabled: true,
  smsEnabled: true,
  pushEnabled: true,
  inAppEnabled: true,
  quietHoursStart: null,
  quietHoursEnd: null,
  quietHoursTimezone: 'Africa/Nairobi',
  language: DEFAULT_NOTIFICATION_LOCALE,
  categoryOverrides: null,
  mutedCategories: [],
};

@Injectable()
export class PreferenceService {
  constructor(
    private readonly preferenceRepository: NotificationPreferenceRepository,
    private readonly eventBus: EventBus,
  ) {}

  async getOrDefault(userId: string, tenantId: string): Promise<NotificationPreference> {
    const existing = await this.preferenceRepository.findByUserId(userId, tenantId);
    if (existing) return existing;

    // Lazily materialize defaults on first read rather than requiring
    // every user-creation flow (owned by a future Users module) to
    // know about notification preferences.
    return this.preferenceRepository.create(
      { ...DEFAULT_PREFERENCE, userId } as Partial<NotificationPreference>,
      tenantId,
    );
  }

  async update(
    userId: string,
    dto: UpdatePreferenceDto,
    tenantId: string,
    actorId?: string,
  ): Promise<NotificationPreference> {
    const current = await this.getOrDefault(userId, tenantId);
    const changedFields = Object.keys(dto).filter(
      (key) => (dto as Record<string, unknown>)[key] !== undefined,
    );

    const updated = await this.preferenceRepository.update(current.id, dto as Partial<NotificationPreference>, tenantId, actorId);

    if (changedFields.length > 0) {
      await this.eventBus.emit(new NotificationPreferenceUpdatedEvent(userId, changedFields));
    }

    return updated;
  }

  /** Whether `channel` is enabled for `category`, honoring per-category overrides and mutes. */
  isChannelAllowed(
    preference: NotificationPreference,
    channel: NotificationChannel,
    category: NotificationCategory,
  ): boolean {
    // EMERGENCY notifications bypass mute/quiet-hours/channel-off
    // preferences by design — this is an intentional, documented
    // exception, not an oversight.
    if (category === NotificationCategory.EMERGENCY) return true;

    if (preference.mutedCategories?.includes(category)) return false;

    const override = preference.categoryOverrides?.[category];
    if (override) return override.includes(channel);

    switch (channel) {
      case NotificationChannel.EMAIL:
        return preference.emailEnabled;
      case NotificationChannel.SMS:
        return preference.smsEnabled;
      case NotificationChannel.PUSH:
        return preference.pushEnabled;
      case NotificationChannel.IN_APP:
      case NotificationChannel.WEBSOCKET:
        return preference.inAppEnabled;
      default:
        return true;
    }
  }

  /** True if `now` (in the user's quiet-hours timezone) falls inside their configured quiet window. */
  isWithinQuietHours(preference: NotificationPreference, now: Date = new Date()): boolean {
    if (!preference.quietHoursStart || !preference.quietHoursEnd) return false;

    const formatter = new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: preference.quietHoursTimezone,
    });
    const currentHHMM = formatter.format(now);

    const { quietHoursStart: start, quietHoursEnd: end } = preference;
    // Handles overnight windows (e.g. 22:00 -> 06:00) as well as same-day windows.
    if (start <= end) {
      return currentHHMM >= start && currentHHMM < end;
    }
    return currentHHMM >= start || currentHHMM < end;
  }
}
