import { Inject, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { EventBus } from '../../infrastructure/events/event-bus.service';
import { JobQueueService } from '../../infrastructure/jobs/job-queue.service';
import { NotificationRepository } from './repositories/notification.repository';
import { Notification } from './interfaces/notification-entity.interface';
import {
  DeliveryStatus,
  NOTIFICATION_JOB_DEFAULT_MAX_ATTEMPTS,
  NOTIFICATION_JOB_NAME,
  NotificationCategory,
  RecipientTargetType,
  RECIPIENT_RESOLVERS,
  DEFAULT_NOTIFICATION_LOCALE,
} from './constants/notification.constants';
import { IRecipientResolver } from './interfaces/notification-channel.interface';
import { NotificationJobData } from './jobs/send-notification.job-handler';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { BroadcastNotificationDto } from './dto/broadcast-notification.dto';
import { NotificationQueryDto } from './dto/notification-query.dto';
import {
  NotificationCancelledEvent,
  NotificationCreatedEvent,
  NotificationEngagementEvent,
} from './events/notification.events';

@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);
  private readonly resolvers = new Map<string, IRecipientResolver>();

  constructor(
    private readonly notificationRepository: NotificationRepository,
    private readonly jobQueueService: JobQueueService,
    private readonly eventBus: EventBus,
    @Inject(RECIPIENT_RESOLVERS) resolvers: IRecipientResolver[],
  ) {
    for (const resolver of resolvers) this.resolvers.set(resolver.targetType, resolver);
  }

  /** Creates a single notification and enqueues it for dispatch. Returns the persisted, PENDING/QUEUED row. */
  async create(dto: CreateNotificationDto, tenantId: string, actorId?: string): Promise<Notification> {
    const notification = await this.notificationRepository.create(
      {
        recipientUserId: dto.recipientUserId,
        category: dto.category,
        channels: dto.channels,
        title: dto.title,
        body: dto.body,
        data: dto.data ?? null,
        templateCode: dto.templateCode ?? null,
        locale: dto.locale ?? DEFAULT_NOTIFICATION_LOCALE,
        status: DeliveryStatus.PENDING,
        failureReason: null,
        attempts: 0,
        maxAttempts: NOTIFICATION_JOB_DEFAULT_MAX_ATTEMPTS,
        scheduledFor: dto.scheduledFor ? new Date(dto.scheduledFor) : null,
        sentAt: null,
        deliveredAt: null,
        readAt: null,
        openedAt: null,
        clickedAt: null,
        cancelledAt: null,
        batchId: null,
        correlationId: dto.correlationId ?? null,
        createdByActor: actorId ?? null,
      } as Partial<Notification>,
      tenantId,
      actorId,
    );

    await this.eventBus.emit(new NotificationCreatedEvent(notification.id, notification.recipientUserId, notification.category));
    await this.enqueue(notification, tenantId);
    return notification;
  }

  /** Resolves the broadcast target into individual recipients and creates one notification per recipient, sharing a batchId. */
  async broadcast(dto: BroadcastNotificationDto, tenantId: string, actorId?: string): Promise<{ batchId: string; count: number }> {
    const resolver = this.resolvers.get(dto.target.targetType);
    if (!resolver) {
      throw new NotFoundException(`No recipient resolver registered for target type "${dto.target.targetType}"`);
    }

    const recipientUserIds =
      dto.target.targetType === RecipientTargetType.CUSTOM_GROUP
        ? await (resolver as { resolve(t: string, tid: string, ids?: string[]): Promise<string[]> }).resolve(
            dto.target.targetId ?? '',
            tenantId,
            dto.target.userIds,
          )
        : await resolver.resolve(dto.target.targetId ?? '', tenantId);

    if (recipientUserIds.length === 0) {
      throw new NotFoundException('Broadcast target resolved to zero recipients');
    }

    const batchId = randomUUID();

    for (const recipientUserId of recipientUserIds) {
      const notification = await this.notificationRepository.create(
        {
          recipientUserId,
          category: dto.category,
          channels: dto.channels,
          title: dto.title,
          body: dto.body,
          data: dto.data ?? null,
          templateCode: dto.templateCode ?? null,
          locale: dto.locale ?? DEFAULT_NOTIFICATION_LOCALE,
          status: DeliveryStatus.PENDING,
          failureReason: null,
          attempts: 0,
          maxAttempts: NOTIFICATION_JOB_DEFAULT_MAX_ATTEMPTS,
          scheduledFor: null,
          sentAt: null,
          deliveredAt: null,
          readAt: null,
          openedAt: null,
          clickedAt: null,
          cancelledAt: null,
          batchId,
          correlationId: null,
          createdByActor: actorId ?? null,
        } as Partial<Notification>,
        tenantId,
        actorId,
      );

      await this.eventBus.emit(
        new NotificationCreatedEvent(notification.id, notification.recipientUserId, notification.category as NotificationCategory),
      );
      await this.enqueue(notification, tenantId);
    }

    this.logger.log(`Broadcast ${batchId}: queued ${recipientUserIds.length} notifications for target type "${dto.target.targetType}"`);
    return { batchId, count: recipientUserIds.length };
  }

  async retry(notificationId: string, tenantId: string): Promise<Notification> {
    const notification = await this.getOrThrow(notificationId, tenantId);

    if (notification.status !== DeliveryStatus.FAILED) {
      throw new NotFoundException(`Notification ${notificationId} is not in a FAILED state and cannot be retried`);
    }

    const updated = await this.notificationRepository.update(
      notificationId,
      { status: DeliveryStatus.PENDING, failureReason: null },
      tenantId,
    );
    await this.enqueue(updated, tenantId);
    return updated;
  }

  async cancel(notificationId: string, tenantId: string, reason?: string): Promise<Notification> {
    const notification = await this.getOrThrow(notificationId, tenantId);

    if ([DeliveryStatus.SENT, DeliveryStatus.DELIVERED, DeliveryStatus.CANCELLED].includes(notification.status as any)) {
      throw new NotFoundException(`Notification ${notificationId} has already been sent/cancelled and cannot be cancelled`);
    }

    const updated = await this.notificationRepository.update(
      notificationId,
      { status: DeliveryStatus.CANCELLED, cancelledAt: new Date() },
      tenantId,
    );
    await this.eventBus.emit(new NotificationCancelledEvent(notificationId, reason));
    return updated;
  }

  async history(query: NotificationQueryDto, tenantId: string) {
    const filters = [
      query.recipientUserId ? { field: 'recipientUserId', operator: 'eq' as const, value: query.recipientUserId } : null,
      query.category ? { field: 'category', operator: 'eq' as const, value: query.category } : null,
      query.status ? { field: 'status', operator: 'eq' as const, value: query.status } : null,
    ].filter(Boolean) as { field: string; operator: 'eq'; value: unknown }[];

    return this.notificationRepository.findMany(
      { filters, pagination: { page: query.page ?? 1, pageSize: query.pageSize ?? 20 } },
      tenantId,
    );
  }

  async markRead(notificationId: string, tenantId: string): Promise<Notification> {
    return this.markEngagement(notificationId, tenantId, DeliveryStatus.READ, 'readAt');
  }

  async markOpened(notificationId: string, tenantId: string): Promise<Notification> {
    return this.markEngagement(notificationId, tenantId, DeliveryStatus.OPENED, 'openedAt');
  }

  async markClicked(notificationId: string, tenantId: string): Promise<Notification> {
    return this.markEngagement(notificationId, tenantId, DeliveryStatus.CLICKED, 'clickedAt');
  }

  async markDelivered(notificationId: string, tenantId: string): Promise<Notification> {
    const updated = await this.notificationRepository.update(
      notificationId,
      { status: DeliveryStatus.DELIVERED, deliveredAt: new Date() },
      tenantId,
    );
    return updated;
  }

  private async markEngagement(
    notificationId: string,
    tenantId: string,
    status: typeof DeliveryStatus.READ | typeof DeliveryStatus.OPENED | typeof DeliveryStatus.CLICKED,
    timestampField: 'readAt' | 'openedAt' | 'clickedAt',
  ): Promise<Notification> {
    const updated = await this.notificationRepository.update(
      notificationId,
      { status, [timestampField]: new Date() } as Partial<Notification>,
      tenantId,
    );
    await this.eventBus.emit(new NotificationEngagementEvent(notificationId, status, `notification.${status.toLowerCase()}`));
    return updated;
  }

  private async getOrThrow(notificationId: string, tenantId: string): Promise<Notification> {
    const notification = await this.notificationRepository.findById(notificationId, tenantId);
    if (!notification) throw new NotFoundException(`Notification ${notificationId} not found`);
    return notification;
  }

  private async enqueue(notification: Notification, tenantId: string): Promise<void> {
    await this.jobQueueService.enqueue<NotificationJobData>(
      NOTIFICATION_JOB_NAME,
      { notificationId: notification.id, tenantId },
      notification.maxAttempts,
    );
    await this.notificationRepository.update(notification.id, { status: DeliveryStatus.QUEUED }, tenantId);
  }
}
