import { Injectable, NotImplementedException } from '@nestjs/common';
import { IRecipientResolver } from '../interfaces/notification-channel.interface';
import { RecipientTargetType } from '../constants/notification.constants';

/** targetId IS the recipient's userId — the trivial single-user case. */
@Injectable()
export class UserRecipientResolver implements IRecipientResolver {
  readonly targetType = RecipientTargetType.USER;

  async resolve(targetId: string): Promise<string[]> {
    return [targetId];
  }
}

/**
 * CUSTOM_GROUP resolves from the explicit userIds array on
 * BroadcastTargetDto rather than a stored group id — there is no
 * "groups" entity in this milestone. NotificationService passes the
 * dto's userIds straight through and this resolver is effectively a
 * pass-through validator, kept as a class so it participates
 * uniformly in the RECIPIENT_RESOLVERS registry.
 */
@Injectable()
export class CustomGroupRecipientResolver implements IRecipientResolver {
  readonly targetType = RecipientTargetType.CUSTOM_GROUP;

  async resolve(_targetId: string, _tenantId: string, explicitUserIds?: string[]): Promise<string[]> {
    return explicitUserIds ?? [];
  }
}

/**
 * Registered as the resolver for CLASS/DEPARTMENT/CAMPUS/INSTITUTION
 * so BroadcastNotificationDto validates against a known set of
 * targetTypes today, without this module reaching into SIS/Org
 * models it must not build (see B2.10 objective constraints). A
 * future module (e.g. B2.x Academic Structure) provides a real
 * resolver and rebinds it in notification.module.ts.
 */
@Injectable()
export class UnresolvedOrgRecipientResolver implements IRecipientResolver {
  constructor(public readonly targetType: string) {}

  async resolve(): Promise<string[]> {
    throw new NotImplementedException(
      `Recipient resolution for target type "${this.targetType}" requires a future org-structure module ` +
        'to register a resolver against the RECIPIENT_RESOLVERS token.',
    );
  }
}
