import { Inject, Injectable, Logger } from '@nestjs/common';
import { ChannelFactory } from './channel.factory';
import { TemplateService } from '../templates/template.service';
import { PreferenceService } from '../preferences/preference.service';
import { RECIPIENT_DIRECTORY, IRecipientDirectory } from '../interfaces/recipient-directory.interface';
import { ChannelDestination, RenderedNotificationMessage } from '../interfaces/notification-channel.interface';
import { Notification } from '../interfaces/notification-entity.interface';
import { NotificationCategory, NotificationChannel } from '../constants/notification.constants';

export interface ChannelDispatchOutcome {
  channel: NotificationChannel;
  success: boolean;
  skipped?: boolean;
  reason?: string;
  providerMessageId?: string;
}

@Injectable()
export class ChannelService {
  private readonly logger = new Logger(ChannelService.name);

  constructor(
    private readonly channelFactory: ChannelFactory,
    private readonly templateService: TemplateService,
    private readonly preferenceService: PreferenceService,
    @Inject(RECIPIENT_DIRECTORY) private readonly recipientDirectory: IRecipientDirectory,
  ) {}

  /** Dispatches one persisted notification across every channel it requested, returning a per-channel outcome. */
  async dispatchAll(notification: Notification, tenantId: string): Promise<ChannelDispatchOutcome[]> {
    const preference = await this.preferenceService.getOrDefault(notification.recipientUserId, tenantId);
    const contactInfo = await this.recipientDirectory.getContactInfo(notification.recipientUserId, tenantId);

    const destination: ChannelDestination = {
      userId: notification.recipientUserId,
      email: (notification.data as Record<string, unknown> | null)?.contactOverride
        ? (notification.data as any).contactOverride.email
        : contactInfo?.email,
      phone: (notification.data as Record<string, unknown> | null)?.contactOverride
        ? (notification.data as any).contactOverride.phone
        : contactInfo?.phone,
      deviceTokens: contactInfo?.deviceTokens,
    };

    const outcomes: ChannelDispatchOutcome[] = [];
    for (const channel of notification.channels) {
      outcomes.push(await this.dispatchOne(notification, channel, destination, preference, tenantId));
    }
    return outcomes;
  }

  private async dispatchOne(
    notification: Notification,
    channel: NotificationChannel,
    destination: ChannelDestination,
    preference: Awaited<ReturnType<PreferenceService['getOrDefault']>>,
    tenantId: string,
  ): Promise<ChannelDispatchOutcome> {
    if (!this.channelFactory.supports(channel)) {
      return { channel, success: false, reason: `Unsupported channel "${channel}"` };
    }

    if (!this.preferenceService.isChannelAllowed(preference, channel, notification.category as NotificationCategory)) {
      return { channel, success: false, skipped: true, reason: 'Disabled by user preference' };
    }

    if (
      channel !== NotificationChannel.IN_APP &&
      notification.category !== NotificationCategory.EMERGENCY &&
      this.preferenceService.isWithinQuietHours(preference)
    ) {
      // IN_APP is exempt: it's a passive record, not an interruption.
      // Deferred re-delivery after quiet hours ends is a documented
      // extension point (see IMPLEMENTATION_SUMMARY_B2_10.md) — for
      // now the notification remains PENDING and is safely re-picked
      // up by a future scheduled re-dispatch job.
      return { channel, success: false, skipped: true, reason: 'Recipient is in quiet hours' };
    }

    const message = await this.renderMessage(notification, channel, destination);

    try {
      const result = await this.channelFactory.resolve(channel).send(message);
      return { channel, success: result.success, reason: result.error, providerMessageId: result.providerMessageId };
    } catch (error) {
      this.logger.error(`Channel "${channel}" threw while sending notification ${notification.id}: ${(error as Error).message}`);
      return { channel, success: false, reason: (error as Error).message };
    }
  }

  private async renderMessage(
    notification: Notification,
    channel: NotificationChannel,
    destination: ChannelDestination,
  ): Promise<RenderedNotificationMessage> {
    const context = { ...(notification.data ?? {}), title: notification.title, body: notification.body };

    if (notification.templateCode) {
      const rendered = await this.templateService.renderForChannel(
        notification.templateCode,
        channel,
        notification.locale,
        context,
        notification.tenantId,
      );
      if (rendered) {
        return {
          recipientUserId: notification.recipientUserId,
          to: destination,
          subject: rendered.subject || notification.title,
          bodyHtml: rendered.bodyHtml,
          bodyText: rendered.bodyText,
          data: notification.data ?? undefined,
          notificationId: notification.id,
          correlationId: notification.correlationId ?? undefined,
        };
      }
    }

    return {
      recipientUserId: notification.recipientUserId,
      to: destination,
      subject: notification.title,
      bodyText: notification.body,
      data: notification.data ?? undefined,
      notificationId: notification.id,
      correlationId: notification.correlationId ?? undefined,
    };
  }
}
