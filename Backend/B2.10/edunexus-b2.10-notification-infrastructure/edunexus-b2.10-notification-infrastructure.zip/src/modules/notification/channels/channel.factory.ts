import { Inject, Injectable } from '@nestjs/common';
import { NOTIFICATION_CHANNEL_PROVIDERS, NotificationChannel } from '../constants/notification.constants';
import { INotificationChannelProvider } from '../interfaces/notification-channel.interface';

/**
 * Registry/factory over all registered INotificationChannelProvider
 * implementations, injected as a multi-provider array under the
 * NOTIFICATION_CHANNEL_PROVIDERS token (wired in notification.module.ts).
 * Adding a new channel = implement the interface + add one line to
 * that provider array; nothing here changes.
 */
@Injectable()
export class ChannelFactory {
  private readonly registry = new Map<NotificationChannel, INotificationChannelProvider>();

  constructor(
    @Inject(NOTIFICATION_CHANNEL_PROVIDERS)
    providers: INotificationChannelProvider[],
  ) {
    for (const provider of providers) {
      this.registry.set(provider.channel, provider);
    }
  }

  resolve(channel: NotificationChannel): INotificationChannelProvider {
    const provider = this.registry.get(channel);
    if (!provider) {
      throw new Error(`No channel provider registered for channel "${channel}"`);
    }
    return provider;
  }

  supports(channel: NotificationChannel): boolean {
    return this.registry.has(channel);
  }
}
