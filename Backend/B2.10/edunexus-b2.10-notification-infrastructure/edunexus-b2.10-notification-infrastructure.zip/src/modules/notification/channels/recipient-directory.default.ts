import { Injectable, Logger } from '@nestjs/common';
import { IRecipientDirectory, RecipientContactInfo } from '../interfaces/recipient-directory.interface';

/**
 * Default binding for IRecipientDirectory. Mirrors the
 * "log and allow through pending the Auth module" pattern used in
 * RolesGuard/PermissionsGuard: rather than throwing, it logs once
 * per lookup and returns null, so EMAIL/SMS/PUSH sends fail
 * gracefully with a clear reason (handled in ChannelService) instead
 * of crashing the dispatch pipeline. IN_APP/WEBSOCKET are unaffected
 * since they only need the userId, not directory-resolved contact info.
 */
@Injectable()
export class NullRecipientDirectory implements IRecipientDirectory {
  private readonly logger = new Logger(NullRecipientDirectory.name);

  async getContactInfo(userId: string, _tenantId: string): Promise<RecipientContactInfo | null> {
    this.logger.warn(
      `No Users module bound to RECIPIENT_DIRECTORY; cannot resolve contact info for user ${userId}. ` +
        'EMAIL/SMS/PUSH will fail unless contactOverride is supplied in the notification payload.',
    );
    return null;
  }
}
