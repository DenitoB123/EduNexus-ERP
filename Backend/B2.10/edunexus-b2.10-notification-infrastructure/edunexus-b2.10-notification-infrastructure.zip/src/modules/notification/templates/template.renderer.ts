import { Injectable } from '@nestjs/common';

/**
 * Lightweight `{{variable}}` interpolation renderer shared by all
 * channels (not just email — infrastructure/email/email-template.engine.ts
 * is EMAIL-specific and stays owned by the email module; this is the
 * notification module's own renderer so SMS/PUSH/IN_APP plain-text
 * bodies get the same {{var}} syntax without depending on the email
 * infrastructure package).
 *
 * Deliberately dependency-free (no Handlebars/Mustache) to keep the
 * module's footprint small; swap the implementation here if richer
 * templating (conditionals/loops) is needed later — callers only see
 * render(source, context).
 */
@Injectable()
export class TemplateRenderer {
  private static readonly PLACEHOLDER = /\{\{\s*([\w.]+)\s*\}\}/g;

  render(source: string, context: Record<string, unknown>): string {
    return source.replace(TemplateRenderer.PLACEHOLDER, (_match, path: string) => {
      const value = this.resolvePath(context, path);
      return value === undefined || value === null ? '' : String(value);
    });
  }

  extractVariableNames(source: string): string[] {
    const names = new Set<string>();
    for (const match of source.matchAll(TemplateRenderer.PLACEHOLDER)) {
      names.add(match[1]);
    }
    return [...names];
  }

  private resolvePath(context: Record<string, unknown>, path: string): unknown {
    return path.split('.').reduce<unknown>((acc, key) => {
      if (acc && typeof acc === 'object') return (acc as Record<string, unknown>)[key];
      return undefined;
    }, context);
  }
}
