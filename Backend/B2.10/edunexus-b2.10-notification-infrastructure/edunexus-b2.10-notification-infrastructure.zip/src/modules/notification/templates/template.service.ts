import { Injectable, Logger } from '@nestjs/common';
import { NotificationTemplateRepository } from '../repositories/notification-template.repository';
import { TemplateRenderer } from './template.renderer';
import { NotificationTemplate } from '../interfaces/notification-entity.interface';
import { DEFAULT_NOTIFICATION_LOCALE, NotificationCategory, NotificationChannel } from '../constants/notification.constants';

export interface RenderedTemplate {
  subject: string;
  bodyHtml?: string;
  bodyText: string;
}

@Injectable()
export class TemplateService {
  private readonly logger = new Logger(TemplateService.name);

  constructor(
    private readonly templateRepository: NotificationTemplateRepository,
    private readonly renderer: TemplateRenderer,
  ) {}

  async create(
    input: {
      code: string;
      name: string;
      category: NotificationCategory;
      channel: NotificationChannel;
      locale?: string;
      subject?: string;
      bodyHtml?: string;
      bodyText: string;
    },
    tenantId: string,
    actorId?: string,
  ): Promise<NotificationTemplate> {
    const locale = input.locale ?? DEFAULT_NOTIFICATION_LOCALE;
    const variables = this.renderer.extractVariableNames(
      [input.subject, input.bodyHtml, input.bodyText].filter(Boolean).join(' '),
    );

    return this.templateRepository.create(
      {
        code: input.code,
        name: input.name,
        category: input.category,
        channel: input.channel,
        locale,
        subject: input.subject ?? null,
        bodyHtml: input.bodyHtml ?? null,
        bodyText: input.bodyText,
        variables,
        isActive: true,
      } as Partial<NotificationTemplate>,
      tenantId,
      actorId,
    );
  }

  /**
   * Resolves a template for (code, channel, locale), falling back to
   * DEFAULT_NOTIFICATION_LOCALE if the requested locale isn't
   * available, then renders it. Returns null if no template exists
   * at all for this code+channel — callers (ChannelService) fall
   * back to the raw title/body supplied on the notification itself.
   */
  async renderForChannel(
    code: string,
    channel: NotificationChannel,
    locale: string,
    context: Record<string, unknown>,
    tenantId: string,
  ): Promise<RenderedTemplate | null> {
    let template = await this.templateRepository.findByCodeChannelLocale(code, channel, locale, tenantId);

    if (!template && locale !== DEFAULT_NOTIFICATION_LOCALE) {
      this.logger.debug(`No "${locale}" template for ${code}/${channel}; falling back to ${DEFAULT_NOTIFICATION_LOCALE}`);
      template = await this.templateRepository.findByCodeChannelLocale(
        code,
        channel,
        DEFAULT_NOTIFICATION_LOCALE,
        tenantId,
      );
    }

    if (!template || !template.isActive) return null;

    return {
      subject: template.subject ? this.renderer.render(template.subject, context) : '',
      bodyHtml: template.bodyHtml ? this.renderer.render(template.bodyHtml, context) : undefined,
      bodyText: this.renderer.render(template.bodyText ?? '', context),
    };
  }
}
