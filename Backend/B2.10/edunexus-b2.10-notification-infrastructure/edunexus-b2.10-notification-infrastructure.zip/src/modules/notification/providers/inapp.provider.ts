import { Injectable } from '@nestjs/common';
import { NotificationChannel } from '../constants/notification.constants';
import {
  ChannelSendResult,
  INotificationChannelProvider,
  RenderedNotificationMessage,
} from '../interfaces/notification-channel.interface';

/**
 * IN_APP has no external transport: the persisted Notification row
 * (already written by NotificationService before any channel runs)
 * *is* the in-app notification. This provider exists purely so
 * IN_APP participates uniformly in ChannelService's dispatch loop,
 * status tracking, and retry accounting.
 */
@Injectable()
export class InAppChannelProvider implements INotificationChannelProvider {
  readonly channel = NotificationChannel.IN_APP;

  async send(_message: RenderedNotificationMessage): Promise<ChannelSendResult> {
    return { success: true };
  }
}
