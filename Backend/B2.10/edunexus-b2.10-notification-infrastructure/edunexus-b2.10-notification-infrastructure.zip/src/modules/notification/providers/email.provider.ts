import { Injectable } from '@nestjs/common';
import { EmailService } from '../../../infrastructure/email/email.service';
import { NotificationChannel } from '../constants/notification.constants';
import {
  ChannelSendResult,
  INotificationChannelProvider,
  RenderedNotificationMessage,
} from '../interfaces/notification-channel.interface';

/**
 * Adapts the notification module's channel contract onto the
 * existing B2.2 infrastructure EmailService (infrastructure/email).
 * This module does NOT re-implement SMTP transport, provider
 * factories, or retry — that already exists. It only maps a
 * RenderedNotificationMessage onto EmailService.send().
 */
@Injectable()
export class EmailChannelProvider implements INotificationChannelProvider {
  readonly channel = NotificationChannel.EMAIL;

  constructor(private readonly emailService: EmailService) {}

  async send(message: RenderedNotificationMessage): Promise<ChannelSendResult> {
    if (!message.to.email) {
      return { success: false, error: 'Recipient has no email address on record' };
    }

    try {
      await this.emailService.send({
        to: message.to.email,
        subject: message.subject,
        html: message.bodyHtml ?? message.bodyText,
        text: message.bodyText,
      });
      return { success: true };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }
}
