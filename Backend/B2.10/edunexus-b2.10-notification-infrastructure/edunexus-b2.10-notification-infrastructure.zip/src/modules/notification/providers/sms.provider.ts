import { Injectable } from '@nestjs/common';
import { SmsService } from '../../../infrastructure/sms/sms.service';
import { NotificationChannel } from '../constants/notification.constants';
import {
  ChannelSendResult,
  INotificationChannelProvider,
  RenderedNotificationMessage,
} from '../interfaces/notification-channel.interface';

@Injectable()
export class SmsChannelProvider implements INotificationChannelProvider {
  readonly channel = NotificationChannel.SMS;

  constructor(private readonly smsService: SmsService) {}

  async send(message: RenderedNotificationMessage): Promise<ChannelSendResult> {
    if (!message.to.phone) {
      return { success: false, error: 'Recipient has no phone number on record' };
    }

    try {
      await this.smsService.send({ to: message.to.phone, message: message.bodyText });
      return { success: true };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }
}
