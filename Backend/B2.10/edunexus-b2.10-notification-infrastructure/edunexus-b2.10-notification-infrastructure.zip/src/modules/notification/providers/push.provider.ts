import { Injectable } from '@nestjs/common';
import { PushService } from '../../../infrastructure/push/push.service';
import { NotificationChannel } from '../constants/notification.constants';
import {
  ChannelSendResult,
  INotificationChannelProvider,
  RenderedNotificationMessage,
} from '../interfaces/notification-channel.interface';

@Injectable()
export class PushChannelProvider implements INotificationChannelProvider {
  readonly channel = NotificationChannel.PUSH;

  constructor(private readonly pushService: PushService) {}

  async send(message: RenderedNotificationMessage): Promise<ChannelSendResult> {
    try {
      // Device token resolution is owned by the existing
      // DeviceRegistrationService (infrastructure/push) — reused
      // here via PushService.sendToSubject rather than duplicated.
      await this.pushService.sendToSubject(
        message.to.userId,
        message.subject,
        message.bodyText,
        message.data as Record<string, string> | undefined,
      );
      return { success: true };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }
}
