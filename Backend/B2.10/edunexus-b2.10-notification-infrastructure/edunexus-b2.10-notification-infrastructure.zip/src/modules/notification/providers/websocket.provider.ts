import { Injectable } from '@nestjs/common';
import { NotificationGateway } from '../gateway/notification.gateway';
import { NotificationChannel } from '../constants/notification.constants';
import {
  ChannelSendResult,
  INotificationChannelProvider,
  RenderedNotificationMessage,
} from '../interfaces/notification-channel.interface';

@Injectable()
export class WebSocketChannelProvider implements INotificationChannelProvider {
  readonly channel = NotificationChannel.WEBSOCKET;

  constructor(private readonly gateway: NotificationGateway) {}

  async send(message: RenderedNotificationMessage): Promise<ChannelSendResult> {
    // Not being "online" is not a failure for this channel — the
    // notification is still persisted (IN_APP row) and will surface
    // next time the client connects/fetches history.
    this.gateway.emitToUser(message.to.userId, 'notification', {
      id: message.notificationId,
      title: message.subject,
      body: message.bodyText,
      data: message.data ?? {},
    });
    return { success: true };
  }
}
