/**
 * B2.10 — Enterprise Notification & Communication Infrastructure.
 *
 * Central enum-like string constants. Kept as `as const` string unions
 * rather than TS `enum` to match Prisma's native enum codegen and to
 * stay trivially serializable across the queue/event boundary.
 */

export const NotificationChannel = {
  EMAIL: 'EMAIL',
  SMS: 'SMS',
  PUSH: 'PUSH',
  IN_APP: 'IN_APP',
  WEBSOCKET: 'WEBSOCKET',
} as const;
export type NotificationChannel = (typeof NotificationChannel)[keyof typeof NotificationChannel];

export const NotificationCategory = {
  ACADEMIC: 'ACADEMIC',
  FINANCE: 'FINANCE',
  ATTENDANCE: 'ATTENDANCE',
  DISCIPLINE: 'DISCIPLINE',
  TRANSPORT: 'TRANSPORT',
  HOSTEL: 'HOSTEL',
  LIBRARY: 'LIBRARY',
  SECURITY: 'SECURITY',
  EMERGENCY: 'EMERGENCY',
  SYSTEM: 'SYSTEM',
} as const;
export type NotificationCategory = (typeof NotificationCategory)[keyof typeof NotificationCategory];

/**
 * Delivery lifecycle. PENDING -> QUEUED -> SENT -> DELIVERED -> {READ|OPENED|CLICKED}
 * FAILED and CANCELLED are terminal off-ramps reachable from PENDING/QUEUED/SENT.
 */
export const DeliveryStatus = {
  PENDING: 'PENDING',
  QUEUED: 'QUEUED',
  SENT: 'SENT',
  DELIVERED: 'DELIVERED',
  FAILED: 'FAILED',
  CANCELLED: 'CANCELLED',
  READ: 'READ',
  OPENED: 'OPENED',
  CLICKED: 'CLICKED',
} as const;
export type DeliveryStatus = (typeof DeliveryStatus)[keyof typeof DeliveryStatus];

export const RecipientTargetType = {
  USER: 'USER',
  CLASS: 'CLASS',
  DEPARTMENT: 'DEPARTMENT',
  CAMPUS: 'CAMPUS',
  INSTITUTION: 'INSTITUTION',
  CUSTOM_GROUP: 'CUSTOM_GROUP',
} as const;
export type RecipientTargetType = (typeof RecipientTargetType)[keyof typeof RecipientTargetType];

/** Job queue routing — consumed by SendNotificationJobHandler via the existing B2.2 JobQueueService/RabbitMQ pipeline. */
export const NOTIFICATION_JOB_NAME = 'notification.dispatch';
export const NOTIFICATION_JOB_DEFAULT_MAX_ATTEMPTS = 5;

/** Event names emitted on the existing B2.2 EventBus. */
export const NotificationEventName = {
  CREATED: 'notification.created',
  QUEUED: 'notification.queued',
  SENT: 'notification.sent',
  DELIVERED: 'notification.delivered',
  FAILED: 'notification.failed',
  CANCELLED: 'notification.cancelled',
  READ: 'notification.read',
  OPENED: 'notification.opened',
  CLICKED: 'notification.clicked',
  PREFERENCE_UPDATED: 'notification.preference.updated',
} as const;

/** DI tokens for extensible, interface-based providers (testability / factory swap-in). */
export const NOTIFICATION_CHANNEL_PROVIDERS = 'NOTIFICATION_CHANNEL_PROVIDERS';
export const RECIPIENT_RESOLVERS = 'RECIPIENT_RESOLVERS';

export const DEFAULT_NOTIFICATION_LOCALE = 'en';
export const SUPPORTED_LOCALES = ['en', 'sw'] as const;
